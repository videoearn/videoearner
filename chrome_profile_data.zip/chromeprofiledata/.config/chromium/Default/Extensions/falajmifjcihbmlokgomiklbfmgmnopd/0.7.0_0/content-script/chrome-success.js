// jsRejectServiceWorkerEnableKey
window.RejectServiceWorker = {key: 'falajmifjcihbmlokgomiklbfmgmnopd'};

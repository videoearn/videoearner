/**
 * 共通処理
 */

const defaultStorage = {
  version: 2,
  whitelist: [],
};

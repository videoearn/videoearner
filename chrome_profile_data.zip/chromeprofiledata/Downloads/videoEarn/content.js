

var prevBase64Data = "";
var rect ="";
var captchaSolved = false;

// Click the button with the text "next video"
function clickButton() {
    const buttonToClick = Array.from(document.querySelectorAll('button')).find(el => el.textContent.toLowerCase().includes("next video"));

    if (buttonToClick) {
        const rect = buttonToClick.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;

        if (centerX === 0) {
            return;
        }

       clickAtCoordinates(centerX,centerY);
    }
}

function clickAtCoordinates(centerX,centerY){
 // Send click coordinates to the extension
        chrome.runtime.sendMessage({
            type: "clickCoordinates",
            x: centerX,
            y: centerY
        });
}



async function solveCaptcha(uniqueClassElement){

    captchaSolved = true;
    setTimeout(function(){
        captchaSolved = false;

    },30000);
    
    document.body.style.zoom = "100%";
    rect = uniqueClassElement.getBoundingClientRect();
    var style = uniqueClassElement.getAttribute('style');

    // Extract the data URI from the style attribute
    var dataURIMatch = style.match(/background\s*:\s*url\(['"]?(data:image\/.*?;base64,.*?)['"]?\)/i);
    var base64Data = "";
    if (dataURIMatch && dataURIMatch[1]) {
        // Get the base64 data by removing the prefix
        base64Data = dataURIMatch[1].replace(/^data:image\/(png|jpeg|jpg|gif);base64,/, '');
    }

    if(!base64Data){
        return;
    }

    if( prevBase64Data == base64Data){
        return;
    }

    prevBase64Data = base64Data;

    if(window.location.href.includes("worksidec.blogspot.com")){
    	let wrapperClass = uniqueClassElement.parentNode.parentNode;
    	const canvas = await html2canvas(wrapperClass,  { backgroundColor: 'black' });
    	const dataUrl = canvas.toDataURL('image/png');
    	base64Data=dataUrl.replace(/^data:image\/(png|jpeg|jpg|gif);base64,/, '');
        rect = uniqueClassElement.parentNode.parentNode.getBoundingClientRect();
    }


  //  console.log(base64Data);



    // Call API to get the coordinates

    // Define your API endpoint
    const apiUrl = 'https://api.cap.guru/in.php';

    // Data to be sent in the POST request
    var postData = {
        key: apiKey,
        method: "base64",
        textinstructions: "custom1223",       
        click: "oth",
        body: base64Data,
        json: "0"
    }

    if(window.location.href.includes("worksidec.blogspot.com")){
     postData.textinstructions ="custom1224";

    }
  
    // Convert data to JSON string
    const jsonData = JSON.stringify(postData);

    // Configure the request
    const requestOptions = {
        method: 'POST',
        //    url: apiUrl,
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'multipart/form-data'
        },
        body: jsonData

    };


    fetch(apiUrl, requestOptions)
        .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.text();
    })
        .then(data => {
        // Handle the response here
        var responseString = data;
        console.log(responseString);
        if (responseString == "ERROR_WRONG_USER_KEY" || responseString == "ERROR_KEY_DOES_NOT_EXIST" || responseString == "ERROR_ZERO_BALANCE" || responseString == "ERROR_ZERO_CAPTCHA_FILESIZE" || responseString == "ERROR_TOO_BIG_CAPTCHA_FILESIZE" || responseString == "ERROR_WRONG_FILE_EXTENSION" || responseString == "ERROR_IMAGE_TYPE_NOT_SUPPORTED") {
            //    setTimeout(function(){
            //      countRetry = countRetry +1;
            //    if(countRetry <= MAX_RETRY_COUNT){
            //      sendToAPI();
            //}

            //},5000);
            return;
        } else if (responseString == "ERROR_IP_NOT_ALLOWED" || responseString == "IP_BANNED") {
            //            userLog("For some reason your IP has been banned from the service. You should disable the plugin and report this.", "error");
            throw new Error("Stopping execution");
        } else if (responseString == "ERROR_NO_SLOT_AVAILABLE") {
        } else {
            setTimeout(parseResponse, 3000, responseString);
        }

    })
        .catch(error => {
        // Handle any errors here
        console.error('Error:', error);
    });
}

function parseResponse(prevResponse) {
    var captchaID = prevResponse.split("|");
    fetch("https://api.cap.guru/res.php?key=" + apiKey + "&action=get&id=" + captchaID[1])
        .then(response => response.text())
        .then(getResponse => {
        console.log(getResponse);

        if (getResponse == "CAPCHA_NOT_READY" || getResponse == "CAPTCHA_NOT_READY") {
            captchaID = null;
            setTimeout(parseResponse, 3000, prevResponse);
            // Deal with errors
        } else if (getResponse == "ERROR_KEY_DOES_NOT_EXIST" || getResponse == "ERROR_WRONG_ID_FORMAT") {
            throw new Error("Stopping execution");
        } else if (getResponse == "ERROR_WRONG_CAPTCHA_ID") {
            // Handle specific error
        } else if (getResponse == "ERROR_CAPTCHA_UNSOLVABLE") {
            // Handle specific error
        } else {
            var captchaArray = getResponse.split("|");
            var captchaAnswer = captchaArray[1];


            // Extracting coordinates
            var coordinatesRegex = /x=(\d+),y=(\d+)/g;
            var matches;
            var coordinates = [];

            while ((matches = coordinatesRegex.exec(captchaAnswer)) !== null) {
                coordinates.push({
                    x: parseInt(matches[1]),
                    y: parseInt(matches[2])
                });
            }

            // Clicking each coordinate
            var coordinateCount=1;
            coordinates.forEach(function(coord) {
                // Calculate the coordinates of the center of the element
              //  console.log(coord);
              //  console.log(coord.x);
              //  console.log(coord.y);

                let centerX = rect.left + coord.x;
                let centerY = rect.top + coord.y;

                if(centerX == 0){
                    return;
                }
                setTimeout(function(){
                    clickAtCoordinates(centerX,centerY);
                },1000*coordinateCount);
                coordinateCount=coordinateCount+1;


            });


            captchaSolved = true;
            setTimeout(function(){
                captchaSolved = false;

            },30000);


        }
    })
        .catch(error => console.error('Fetch error:', error));
}


function monitorCaptcha() {

    let wrapperClass = document.querySelector("[class='wrapper']");
    if(!wrapperClass){
        return;
    }
    // Find elements with style attribute containing "background url"
    var elementsWithBackgroundUrl = wrapperClass.querySelectorAll('[style*="background: url("]');

    if(elementsWithBackgroundUrl && elementsWithBackgroundUrl.length==1){
         solveCaptcha(elementsWithBackgroundUrl[0]);
         return;
    }

    // Create an object to store occurrences of class names
    var classNameOccurrences = {};

    // Loop through the found elements
    elementsWithBackgroundUrl.forEach(function(element) {
        // Get the class name of each element
        var className = element.className;

        // Count occurrences of each class name
        classNameOccurrences[className] = (classNameOccurrences[className] || 0) + 1;
    });

    // Find the unique class name
    var uniqueClassName = Object.keys(classNameOccurrences).find(function(className) {
        return classNameOccurrences[className] === 1;
    });

    if(!uniqueClassName){
        return;
    }

    // Find the element with the unique class name
    var uniqueClassElement = document.querySelector('.' + uniqueClassName);


    if(uniqueClassElement && !captchaSolved){
        solveCaptcha(uniqueClassElement);


    }
}


// Click on the YouTube video play button
function youtubeButtonClicker() {
    let buttonToClick = document.querySelector("#movie_player > div.ytp-cued-thumbnail-overlay > button");

    if(!buttonToClick){
       return
    }
    const rect = buttonToClick.getBoundingClientRect();

    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    // Send click coordinates to the extension
    chrome.runtime.sendMessage({
        type: "clickCoordinates",
        x: centerX,
        y: centerY
    });
}




// Click the "next video" button on specific pages
function nextVideoClicker() {
    var interval = setInterval(function () {
        monitorCaptcha();

        if (Array.from(document.querySelectorAll('button')).find(el => el.textContent.toLowerCase().includes("next video"))) {        
                clickButton();
        } else {
            clearInterval(interval);
        }
    }, 10000);
}

// Execute shortlinkStepClicker on specific pages
if (window.location.href.includes("squarespace.com") || window.location.href.includes("bestytvid.blogspot.com") || 
    window.location.href.includes("worksidec.blogspot.com")) {
    nextVideoClicker();
}

// Execute youtubeButtonClicker on YouTube pages
if (window.location.href.includes("youtube.com")) {
    console.clear();
    setTimeout(function () {
        youtubeButtonClicker();
    }, 5000);
}